import { Stack } from "expo-router";
import { CounterProvider } from "./(tabs)/log-item/CounterContext";

export default function AppLayout() {
  return (
    <CounterProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="log-item" />
      </Stack>
    </CounterProvider>
  );
}